sed -i 's/Tigress/Griffin/g' *
sed -i 's/tg./gr./g' *
sed -i 's/TIGR/GRIF/g' *
